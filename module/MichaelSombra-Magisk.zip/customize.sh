#!/sbin/sh

SKIPUNZIP=1

ui_print ""
ui_print "  ╔══════════════════════════════╗"
ui_print "  ║    Michael Sombra v1.3       ║"
ui_print "  ║  by Michael Antonio          ║"
ui_print "  ║     Rodriguez Condega         ║"
ui_print "  ╚══════════════════════════════╝"
ui_print ""

# Extract module files if not already extracted
if [ ! -d "$MODPATH/system" ]; then
    ui_print "  📦 Extrayendo archivos..."
    unzip -o "$ZIPFILE" -d "$MODPATH" 2>/dev/null
fi

# Detect root environment
if [ -f /data/adb/magisk/util_functions.sh ]; then
    ui_print "  🔧 Entorno: Magisk"
elif [ -f /data/adb/ksu/util_functions.sh ]; then
    ui_print "  🔧 Entorno: KernelSU"
elif [ -f /data/adb/ap/util_functions.sh ]; then
    ui_print "  🔧 Entorno: APatch"
else
    ui_print "  🔧 Entorno: Root (genérico)"
fi

# Set permissions for the APK
ui_print "  🔧 Configurando permisos..."
set_perm_recursive "$MODPATH/system/priv-app/MichaelSombra" 0 0 0755 0644
set_perm "$MODPATH/system/priv-app/MichaelSombra/MichaelSombra.apk" 0 0 0644

# Remove customize.sh from module to save space
rm -f "$MODPATH/customize.sh"

ui_print ""
ui_print "  ✅ Instalación completada"
ui_print "  🔄 Reinicia el dispositivo"
ui_print ""
ui_print "  ⚡ Después de reiniciar:"
ui_print "     La app aparecerá en el cajón"
ui_print "     como app del sistema."
ui_print ""
