#!/sbin/sh

# Michael Sombra - Post-boot service
# Grant SYSTEM_ALERT_WINDOW permission automatically if possible

MODPATH=${0%/*}

sleep 10

# Try to grant overlay permission for system app
if [ -d /system/priv-app/MichaelSombra ]; then
    pm grant com.michael.sombra android.permission.SYSTEM_ALERT_WINDOW 2>/dev/null
fi

# Alternative method via appops
appops set com.michael.sombra SYSTEM_ALERT_WINDOW allow 2>/dev/null

exit 0
